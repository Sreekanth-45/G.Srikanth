export type CategoryId =
  | 'all'
  | 'general'
  | 'technology'
  | 'business'
  | 'sports'
  | 'entertainment'
  | 'health'
  | 'science';

export interface CategoryMeta {
  id: CategoryId;
  label: string;
  description: string;
}

export interface Article {
  id: string;
  title: string;
  description: string | null;
  content: string | null;
  url: string;
  imageUrl: string | null;
  source: string;
  author: string | null;
  category: Exclude<CategoryId, 'all'>;
  publishedAt: string;
}

export interface NewsFeedResponse {
  articles: Article[];
  totalResults: number;
  category: CategoryId;
  query: string;
  provider: string;
  notice?: string;
}

export interface Bookmark {
  id: string;
  url: string;
  title: string;
  description: string | null;
  content: string | null;
  imageUrl: string | null;
  source: string;
  author: string | null;
  category: Exclude<CategoryId, 'all'>;
  publishedAt: string;
  createdAt: string;
}

export interface ArticleNote {
  id: number;
  articleId: string;
  articleUrl: string;
  articleTitle: string;
  noteContent: string;
  createdAt: string;
  updatedAt: string;
}
