import { AlertCircle, Loader2, Newspaper, RefreshCw } from 'lucide-react';
import type { Article } from '../types/news';
import NewsCard from './NewsCard';

interface NewsFeedProps {
  articles: Article[];
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onResetFilters?: () => void;
  showFeatured?: boolean;
  emptyTitle?: string;
  emptyDescription?: string;
}

export default function NewsFeed({
  articles,
  loading,
  error,
  onRetry,
  onResetFilters,
  showFeatured = true,
  emptyTitle = 'No matching articles found',
  emptyDescription = 'Try clearing your keyword search or switching to another news category.',
}: NewsFeedProps) {
  if (loading) {
    return (
      <div
        role="status"
        aria-live="polite"
        className="flex flex-col items-center justify-center rounded-lg border border-stone-200 bg-white px-6 py-20 text-center dark:border-slate-800 dark:bg-slate-900"
      >
        <Loader2
          className="mb-3 h-8 w-8 animate-spin text-[#0F1E36] dark:text-amber-400"
          aria-hidden="true"
        />
        <p className="text-sm font-medium text-stone-700 dark:text-slate-200">
          Fetching latest news articles...
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div
        role="alert"
        className="flex flex-col items-center justify-center rounded-lg border border-red-200 bg-red-50/70 px-6 py-14 text-center dark:border-red-900/60 dark:bg-red-950/30"
      >
        <AlertCircle className="mb-3 h-8 w-8 text-red-700 dark:text-red-400" aria-hidden="true" />
        <h3 className="font-serif text-lg font-bold text-stone-900 dark:text-slate-100">
          Unable to Load News Feed
        </h3>
        <p className="mt-1.5 max-w-md text-sm text-stone-600 dark:text-slate-300">{error}</p>
        <button
          type="button"
          onClick={onRetry}
          className="mt-5 inline-flex items-center gap-2 rounded-md bg-[#0F1E36] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#193055] cursor-pointer dark:bg-amber-600 dark:hover:bg-amber-500"
        >
          <RefreshCw className="h-4 w-4" aria-hidden="true" />
          <span>Try Again</span>
        </button>
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border border-stone-200 bg-white px-6 py-16 text-center dark:border-slate-800 dark:bg-slate-900">
        <Newspaper className="mb-3 h-9 w-9 text-stone-400 dark:text-slate-500" aria-hidden="true" />
        <h3 className="font-serif text-xl font-bold text-stone-900 dark:text-slate-100">
          {emptyTitle}
        </h3>
        <p className="mt-2 max-w-md text-sm text-stone-600 dark:text-slate-400">
          {emptyDescription}
        </p>
        {onResetFilters && (
          <button
            type="button"
            onClick={onResetFilters}
            className="mt-5 inline-flex items-center rounded-md border border-stone-300 bg-stone-50 px-4 py-2 text-sm font-medium text-stone-800 transition-colors hover:bg-stone-100 cursor-pointer dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
          >
            View All News Articles
          </button>
        )}
      </div>
    );
  }

  const [leadArticle, ...restArticles] = articles;
  const gridArticles = showFeatured ? restArticles : articles;

  return (
    <div className="space-y-8">
      {showFeatured && leadArticle && <NewsCard article={leadArticle} featured />}

      {gridArticles.length > 0 && (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {gridArticles.map((article) => (
            <NewsCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  );
}
