import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-stone-200 bg-white py-8 text-sm text-stone-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
      <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 sm:flex-row sm:items-center sm:px-6 lg:px-8">
        <div>
          <p className="font-serif font-bold text-stone-900 dark:text-slate-100">News Reader</p>
          <p className="mt-0.5 text-xs text-stone-500 dark:text-slate-400">
            Personal News Reading Application · College Laboratory Submission
          </p>
        </div>

        <nav aria-label="Footer navigation" className="flex flex-wrap items-center gap-6 text-xs font-medium">
          <Link to="/" className="hover:text-stone-900 dark:hover:text-white transition-colors">
            Home
          </Link>
          <Link
            to="/categories"
            className="hover:text-stone-900 dark:hover:text-white transition-colors"
          >
            Categories
          </Link>
          <Link
            to="/bookmarks"
            className="hover:text-stone-900 dark:hover:text-white transition-colors"
          >
            Bookmarks
          </Link>
          <Link to="/about" className="hover:text-stone-900 dark:hover:text-white transition-colors">
            About
          </Link>
        </nav>
      </div>
    </footer>
  );
}
