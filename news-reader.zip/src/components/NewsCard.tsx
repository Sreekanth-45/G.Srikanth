import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Article } from '../types/news';
import { formatPublishedDate, getCategoryLabel } from '../utils/formatters';
import ArticleImage from './ArticleImage';
import BookmarkButton from './BookmarkButton';

interface NewsCardProps {
  article: Article;
  featured?: boolean;
}

export default function NewsCard({ article, featured = false }: NewsCardProps) {
  const categoryLabel = getCategoryLabel(article.category);
  const formattedDate = formatPublishedDate(article.publishedAt);
  const summary =
    article.description ||
    'Summary unavailable from publisher feed. Open the article details or original source to read more.';

  if (featured) {
    return (
      <article className="group overflow-hidden rounded-lg border border-stone-200 bg-white transition-shadow duration-150 hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
        <div className="grid grid-cols-1 items-stretch lg:grid-cols-12">
          <Link
            to={`/article/${article.id}`}
            state={{ article }}
            className="block overflow-hidden bg-stone-100 lg:col-span-7 dark:bg-slate-800"
          >
            <ArticleImage
              src={article.imageUrl}
              alt={article.title}
              category={article.category}
              className="aspect-[16/10] w-full transition-transform duration-200 group-hover:scale-[1.02] lg:h-full lg:aspect-auto"
            />
          </Link>

          <div className="flex flex-col justify-between p-6 sm:p-8 lg:col-span-5">
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-stone-500 tabular-nums dark:text-slate-400">
                <span className="text-[#9A3412] dark:text-amber-400">{categoryLabel}</span>
                <span aria-hidden="true">·</span>
                <span>{article.source}</span>
                <span aria-hidden="true">·</span>
                <time dateTime={article.publishedAt}>{formattedDate}</time>
              </div>

              <h2 className="font-editorial font-serif text-2xl font-bold leading-snug text-stone-900 sm:text-3xl dark:text-slate-50">
                <Link
                  to={`/article/${article.id}`}
                  state={{ article }}
                  className="hover:text-[#0F1E36] dark:hover:text-amber-300 transition-colors"
                >
                  {article.title}
                </Link>
              </h2>

              <p className="text-sm leading-relaxed text-stone-600 line-clamp-4 sm:text-base dark:text-slate-300">
                {summary}
              </p>
            </div>

            <div className="mt-6 flex items-center justify-between gap-4 border-t border-stone-100 pt-5 dark:border-slate-800">
              <Link
                to={`/article/${article.id}`}
                state={{ article }}
                className="inline-flex items-center gap-2 rounded-md bg-[#0F1E36] px-4 py-2 text-sm font-medium text-white transition-colors duration-150 hover:bg-[#193055] whitespace-nowrap shrink-0 dark:bg-amber-600 dark:hover:bg-amber-500"
              >
                <span>Read More</span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
              <BookmarkButton article={article} variant="icon" />
            </div>
          </div>
        </div>
      </article>
    );
  }

  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-lg border border-stone-200 bg-white transition-shadow duration-150 hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
      <Link
        to={`/article/${article.id}`}
        state={{ article }}
        className="block overflow-hidden bg-stone-100 dark:bg-slate-800"
      >
        <ArticleImage
          src={article.imageUrl}
          alt={article.title}
          category={article.category}
          className="aspect-[4/3] w-full transition-transform duration-200 group-hover:scale-[1.02]"
        />
      </Link>

      <div className="flex flex-1 flex-col justify-between p-5">
        <div className="space-y-2.5">
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium text-stone-500 tabular-nums dark:text-slate-400">
            <span className="text-[#9A3412] dark:text-amber-400">{categoryLabel}</span>
            <span aria-hidden="true">·</span>
            <span className="truncate max-w-[140px]">{article.source}</span>
            <span aria-hidden="true">·</span>
            <time dateTime={article.publishedAt}>{formattedDate}</time>
          </div>

          <h3 className="font-editorial font-serif text-lg font-bold leading-snug text-stone-900 line-clamp-3 dark:text-slate-50">
            <Link
              to={`/article/${article.id}`}
              state={{ article }}
              className="hover:text-[#0F1E36] dark:hover:text-amber-300 transition-colors"
            >
              {article.title}
            </Link>
          </h3>

          <p className="text-sm leading-relaxed text-stone-600 line-clamp-3 dark:text-slate-300">
            {summary}
          </p>
        </div>

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-stone-100 pt-4 dark:border-slate-800">
          <Link
            to={`/article/${article.id}`}
            state={{ article }}
            className="inline-flex items-center gap-1.5 rounded-md border border-stone-300 bg-stone-50 px-3.5 py-2 text-xs font-semibold text-stone-900 transition-colors duration-150 hover:bg-[#0F1E36] hover:border-[#0F1E36] hover:text-white whitespace-nowrap shrink-0 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-amber-600 dark:hover:border-amber-600"
          >
            <span>Read More</span>
            <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </Link>

          <BookmarkButton article={article} variant="icon" />
        </div>
      </div>
    </article>
  );
}
