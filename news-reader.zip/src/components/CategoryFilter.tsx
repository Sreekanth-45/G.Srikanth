import type { CategoryId } from '../types/news';
import { CATEGORIES } from '../utils/formatters';

interface CategoryFilterProps {
  selectedCategory: CategoryId;
  onSelectCategory: (category: CategoryId) => void;
}

export default function CategoryFilter({
  selectedCategory,
  onSelectCategory,
}: CategoryFilterProps) {
  return (
    <div
      role="tablist"
      aria-label="News categories"
      className="flex items-center gap-1.5 overflow-x-auto border-b border-stone-200 pb-3 dark:border-slate-800"
    >
      {CATEGORIES.map((category) => {
        const isActive = selectedCategory === category.id;
        return (
          <button
            key={category.id}
            type="button"
            role="tab"
            aria-selected={isActive}
            onClick={() => onSelectCategory(category.id)}
            className={`rounded-md px-3.5 py-2 text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F1E36] dark:focus-visible:outline-amber-400 ${
              isActive
                ? 'bg-[#0F1E36] text-white dark:bg-amber-600 dark:text-white'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
            }`}
          >
            {category.label}
          </button>
        );
      })}
    </div>
  );
}
