import { Menu, Moon, Newspaper, Sun, X } from 'lucide-react';
import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useNewsReader } from '../context/NewsReaderContext';

export default function Navbar() {
  const { bookmarks, theme, toggleTheme } = useNewsReader();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `relative py-1 text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white ${
      isActive
        ? 'text-white underline decoration-amber-400 decoration-2 underline-offset-8'
        : 'text-slate-200 hover:text-white'
    }`;

  return (
    <header className="bg-[#0F1E36] text-white border-b border-slate-800/80 dark:bg-slate-900 dark:border-slate-800">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        <Link
          to="/"
          onClick={() => setMobileMenuOpen(false)}
          className="flex items-center gap-2.5 font-serif text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white"
        >
          <Newspaper className="h-5 w-5 text-amber-400" aria-hidden="true" />
          <span>News Reader</span>
        </Link>

        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7"
        >
          <NavLink to="/" end className={navLinkClass}>
            Home
          </NavLink>
          <NavLink to="/categories" className={navLinkClass}>
            Categories
          </NavLink>
          <NavLink to="/bookmarks" className={navLinkClass}>
            <span className="tabular-nums">
              {bookmarks.length > 0 ? `Bookmarks (${bookmarks.length})` : 'Bookmarks'}
            </span>
          </NavLink>
          <NavLink to="/about" className={navLinkClass}>
            About
          </NavLink>
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={toggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className="hidden md:inline-flex items-center gap-2 rounded-md border border-slate-600/80 bg-slate-800/60 px-3.5 py-2 text-xs font-medium text-slate-100 transition-colors duration-150 hover:bg-slate-700/80 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
          >
            {theme === 'dark' ? (
              <>
                <Sun className="h-4 w-4 text-amber-300" aria-hidden="true" />
                <span>Light Mode</span>
              </>
            ) : (
              <>
                <Moon className="h-4 w-4 text-slate-200" aria-hidden="true" />
                <span>Dark Mode</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-slate-700 text-slate-100 hover:bg-slate-800 md:hidden cursor-pointer focus-visible:outline-2 focus-visible:outline-white"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="border-t border-slate-800 bg-[#0F1E36] px-4 py-4 md:hidden dark:bg-slate-900">
          <nav aria-label="Mobile navigation" className="flex flex-col gap-1">
            <NavLink
              to="/"
              end
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-md px-3 py-2.5 text-sm font-medium text-slate-100 hover:bg-slate-800"
            >
              Home
            </NavLink>
            <NavLink
              to="/categories"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-md px-3 py-2.5 text-sm font-medium text-slate-100 hover:bg-slate-800"
            >
              Categories
            </NavLink>
            <NavLink
              to="/bookmarks"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-md px-3 py-2.5 text-sm font-medium text-slate-100 hover:bg-slate-800 tabular-nums"
            >
              {bookmarks.length > 0 ? `Bookmarks (${bookmarks.length})` : 'Bookmarks'}
            </NavLink>
            <NavLink
              to="/about"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-md px-3 py-2.5 text-sm font-medium text-slate-100 hover:bg-slate-800"
            >
              About
            </NavLink>
            <button
              type="button"
              onClick={toggleTheme}
              className="mt-2 flex items-center gap-2 rounded-md border border-slate-700 px-3 py-2.5 text-left text-sm font-medium text-slate-100 hover:bg-slate-800 cursor-pointer"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="h-4 w-4 text-amber-300" aria-hidden="true" />
                  <span>Switch to Light Mode</span>
                </>
              ) : (
                <>
                  <Moon className="h-4 w-4 text-slate-200" aria-hidden="true" />
                  <span>Switch to Dark Mode</span>
                </>
              )}
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
