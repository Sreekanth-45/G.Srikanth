import { Newspaper } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { CategoryId } from '../types/news';
import { getFallbackImage } from '../utils/formatters';

interface ArticleImageProps {
  src: string | null;
  alt: string;
  category: CategoryId;
  className?: string;
}

export default function ArticleImage({ src, alt, category, className = '' }: ArticleImageProps) {
  const fallbackSrc = getFallbackImage(category);
  const [currentSrc, setCurrentSrc] = useState<string>(src || fallbackSrc);
  const [failedCompletely, setFailedCompletely] = useState(false);

  useEffect(() => {
    setCurrentSrc(src || fallbackSrc);
    setFailedCompletely(false);
  }, [src, fallbackSrc]);

  if (failedCompletely) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-stone-200 via-stone-100 to-stone-200 p-6 text-center text-stone-500 dark:from-slate-800 dark:via-slate-900 dark:to-slate-800 dark:text-slate-400 ${className}`}
      >
        <Newspaper className="mb-2 h-8 w-8 opacity-60" aria-hidden="true" />
        <span className="font-serif text-sm font-medium line-clamp-2 max-w-xs">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={currentSrc}
      alt={alt}
      referrerPolicy="no-referrer"
      loading="lazy"
      onError={() => {
        if (currentSrc !== fallbackSrc) {
          setCurrentSrc(fallbackSrc);
        } else {
          setFailedCompletely(true);
        }
      }}
      className={`object-cover ${className}`}
    />
  );
}
