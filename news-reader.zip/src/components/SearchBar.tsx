import { Search, X } from 'lucide-react';
import { useState, type FormEvent } from 'react';
import { SEARCH_SUGGESTIONS } from '../utils/formatters';

interface SearchBarProps {
  query: string;
  onSearch: (value: string) => void;
  onClear: () => void;
}

export default function SearchBar({ query, onSearch, onClear }: SearchBarProps) {
  const [inputValue, setInputValue] = useState(query);

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    onSearch(inputValue.trim());
  };

  const handleClear = () => {
    setInputValue('');
    onClear();
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion);
    onSearch(suggestion);
  };

  return (
    <div className="space-y-3">
      <form onSubmit={handleSubmit} className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search
            className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400 dark:text-slate-500"
            aria-hidden="true"
          />
          <input
            type="search"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Search news by keyword (e.g., Artificial Intelligence, Cricket, Indian Economy)..."
            aria-label="Search news articles"
            className="w-full rounded-md border border-stone-300 bg-white py-2.5 pl-10 pr-10 text-sm text-stone-900 placeholder:text-stone-400 transition-colors focus:border-[#0F1E36] focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-amber-400"
          />
          {(inputValue || query) && (
            <button
              type="button"
              onClick={handleClear}
              aria-label="Clear search"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-stone-400 hover:text-stone-700 dark:text-slate-500 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="submit"
            className="inline-flex items-center justify-center rounded-md bg-[#0F1E36] px-5 py-2.5 text-sm font-medium text-white transition-colors duration-150 hover:bg-[#193055] whitespace-nowrap shrink-0 cursor-pointer dark:bg-amber-600 dark:hover:bg-amber-500"
          >
            Search
          </button>
          {query && (
            <button
              type="button"
              onClick={handleClear}
              className="inline-flex items-center justify-center rounded-md border border-stone-300 bg-white px-4 py-2.5 text-sm font-medium text-stone-700 transition-colors duration-150 hover:bg-stone-100 whitespace-nowrap shrink-0 cursor-pointer dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              Clear
            </button>
          )}
        </div>
      </form>

      <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-stone-500 dark:text-slate-400">
        <span className="font-medium text-stone-600 dark:text-slate-300">Suggested topics:</span>
        {SEARCH_SUGGESTIONS.map((topic) => (
          <button
            key={topic}
            type="button"
            onClick={() => handleSuggestionClick(topic)}
            className="underline decoration-stone-300 underline-offset-4 transition-colors hover:text-[#0F1E36] hover:decoration-[#0F1E36] dark:decoration-slate-700 dark:hover:text-amber-300 dark:hover:decoration-amber-300 cursor-pointer"
          >
            {topic}
          </button>
        ))}
      </div>
    </div>
  );
}
