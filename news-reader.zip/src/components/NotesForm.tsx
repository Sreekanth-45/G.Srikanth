import { Check, Pencil, Plus, Trash2, X } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';
import {
  createArticleNote,
  deleteArticleNote,
  fetchNotes,
  updateArticleNote,
} from '../services/api';
import type { ArticleNote } from '../types/news';
import { formatDateTime } from '../utils/formatters';

interface NotesFormProps {
  articleId: string;
  articleUrl: string;
  articleTitle: string;
}

export default function NotesForm({ articleId, articleUrl, articleTitle }: NotesFormProps) {
  const [notes, setNotes] = useState<ArticleNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [draftNote, setDraftNote] = useState('');
  const [saving, setSaving] = useState(false);

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editContent, setEditContent] = useState('');
  const [editSaving, setEditSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        setLoading(true);
        setError(null);
        const list = await fetchNotes(articleId);
        if (!cancelled) setNotes(list);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Could not load saved notes.');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [articleId]);

  const handleCreate = async (event: FormEvent) => {
    event.preventDefault();
    const trimmed = draftNote.trim();
    if (!trimmed || saving) return;

    try {
      setSaving(true);
      setError(null);
      const created = await createArticleNote({
        articleId,
        articleUrl,
        articleTitle,
        noteContent: trimmed,
      });
      setNotes((prev) => [created, ...prev]);
      setDraftNote('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save note.');
    } finally {
      setSaving(false);
    }
  };

  const startEdit = (note: ArticleNote) => {
    setEditingId(note.id);
    setEditContent(note.noteContent);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditContent('');
  };

  const handleUpdate = async (id: number) => {
    const trimmed = editContent.trim();
    if (!trimmed || editSaving) return;
    try {
      setEditSaving(true);
      setError(null);
      const updated = await updateArticleNote(id, trimmed);
      setNotes((prev) => prev.map((n) => (n.id === id ? updated : n)));
      setEditingId(null);
      setEditContent('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update note.');
    } finally {
      setEditSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      setError(null);
      await deleteArticleNote(id);
      setNotes((prev) => prev.filter((n) => n.id !== id));
      if (editingId === id) {
        cancelEdit();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete note.');
    }
  };

  return (
    <section
      aria-labelledby="personal-notes-heading"
      className="rounded-lg border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900"
    >
      <div className="border-b border-stone-200 pb-4 dark:border-slate-800">
        <h2
          id="personal-notes-heading"
          className="font-serif text-xl font-bold text-stone-900 dark:text-slate-50"
        >
          Personal Reading Notes
        </h2>
        <p className="mt-1 text-xs text-stone-500 dark:text-slate-400">
          Notes are saved persistently to the local SQLite database for this article.
        </p>
      </div>

      <form onSubmit={handleCreate} className="mt-5 space-y-4">
        <div>
          <label
            htmlFor="note-article-title"
            className="block text-xs font-semibold text-stone-600 dark:text-slate-300"
          >
            Article Title
          </label>
          <input
            id="note-article-title"
            type="text"
            value={articleTitle}
            readOnly
            className="mt-1.5 w-full rounded-md border border-stone-200 bg-stone-50 px-3 py-2 text-sm text-stone-700 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300"
          />
        </div>

        <div>
          <label
            htmlFor="note-content-input"
            className="block text-xs font-semibold text-stone-600 dark:text-slate-300"
          >
            Your Note
          </label>
          <textarea
            id="note-content-input"
            rows={4}
            value={draftNote}
            onChange={(e) => setDraftNote(e.target.value)}
            placeholder="Write key takeaways, study points, or reflections on this article..."
            required
            className="mt-1.5 w-full rounded-md border border-stone-300 bg-white px-3.5 py-2.5 text-sm leading-relaxed text-stone-900 placeholder:text-stone-400 focus:border-[#0F1E36] focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-amber-400"
          />
        </div>

        {error && (
          <p role="alert" className="text-xs font-medium text-red-700 dark:text-red-400">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={saving || !draftNote.trim()}
          className="inline-flex items-center gap-2 rounded-md bg-[#0F1E36] px-4 py-2.5 text-sm font-medium text-white transition-colors duration-150 hover:bg-[#193055] disabled:opacity-50 cursor-pointer dark:bg-amber-600 dark:hover:bg-amber-500"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>{saving ? 'Saving Note...' : 'Save Note'}</span>
        </button>
      </form>

      <div className="mt-8 border-t border-stone-200 pt-5 dark:border-slate-800">
        <h3 className="text-sm font-semibold text-stone-800 tabular-nums dark:text-slate-200">
          Saved Notes ({notes.length})
        </h3>

        {loading ? (
          <p className="mt-3 text-sm text-stone-500 dark:text-slate-400">Loading notes...</p>
        ) : notes.length === 0 ? (
          <p className="mt-3 text-sm text-stone-500 dark:text-slate-400">
            No personal notes saved for this article yet.
          </p>
        ) : (
          <ul className="mt-4 space-y-4">
            {notes.map((note) => {
              const isEditing = editingId === note.id;
              return (
                <li
                  key={note.id}
                  className="rounded-md border border-stone-200 bg-[#FBF9F5] p-4 dark:border-slate-800 dark:bg-slate-950"
                >
                  {isEditing ? (
                    <div className="space-y-3">
                      <textarea
                        rows={3}
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                        aria-label="Edit personal note"
                        className="w-full rounded-md border border-stone-300 bg-white px-3 py-2 text-sm text-stone-900 focus:border-[#0F1E36] focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                      />
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleUpdate(note.id)}
                          disabled={editSaving || !editContent.trim()}
                          className="inline-flex items-center gap-1.5 rounded-md bg-[#0F1E36] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#193055] disabled:opacity-50 cursor-pointer dark:bg-amber-600 dark:hover:bg-amber-500"
                        >
                          <Check className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>{editSaving ? 'Saving...' : 'Save Note'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={cancelEdit}
                          className="inline-flex items-center gap-1.5 rounded-md border border-stone-300 bg-white px-3 py-1.5 text-xs font-medium text-stone-700 hover:bg-stone-100 cursor-pointer dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                        >
                          <X className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Cancel</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p className="whitespace-pre-wrap text-sm leading-relaxed text-stone-800 dark:text-slate-200">
                        {note.noteContent}
                      </p>
                      <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-stone-200/80 pt-3 text-xs text-stone-500 tabular-nums dark:border-slate-800 dark:text-slate-400">
                        <span>
                          Updated {formatDateTime(note.updatedAt)}
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => startEdit(note)}
                            className="inline-flex items-center gap-1 rounded px-2.5 py-1 text-xs font-medium text-stone-700 hover:bg-stone-200/70 cursor-pointer dark:text-slate-300 dark:hover:bg-slate-800"
                          >
                            <Pencil className="h-3.5 w-3.5" aria-hidden="true" />
                            <span>Edit Note</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(note.id)}
                            className="inline-flex items-center gap-1 rounded px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-100 cursor-pointer dark:text-red-400 dark:hover:bg-red-950/60"
                          >
                            <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                            <span>Delete Note</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}
