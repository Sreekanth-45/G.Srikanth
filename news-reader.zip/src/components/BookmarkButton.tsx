import { Bookmark } from 'lucide-react';
import { useState } from 'react';
import { useNewsReader } from '../context/NewsReaderContext';
import type { Article } from '../types/news';

interface BookmarkButtonProps {
  article: Article;
  variant?: 'icon' | 'button';
}

export default function BookmarkButton({ article, variant = 'icon' }: BookmarkButtonProps) {
  const { isBookmarked, toggleBookmark } = useNewsReader();
  const [pending, setPending] = useState(false);
  const saved = isBookmarked(article.id);

  const handleClick = async () => {
    if (pending) return;
    try {
      setPending(true);
      await toggleBookmark(article);
    } finally {
      setPending(false);
    }
  };

  if (variant === 'button') {
    return (
      <button
        type="button"
        onClick={handleClick}
        disabled={pending}
        aria-pressed={saved}
        className={`inline-flex items-center gap-2 rounded-md border px-4 py-2.5 text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F1E36] dark:focus-visible:outline-amber-400 ${
          saved
            ? 'border-amber-700 bg-amber-50 text-amber-900 hover:bg-amber-100 dark:border-amber-500/50 dark:bg-amber-950/50 dark:text-amber-200 dark:hover:bg-amber-900/50'
            : 'border-stone-300 bg-white text-stone-800 hover:bg-stone-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800'
        }`}
      >
        <Bookmark
          className={`h-4 w-4 ${saved ? 'fill-amber-600 text-amber-700 dark:fill-amber-400 dark:text-amber-300' : ''}`}
          aria-hidden="true"
        />
        <span>{saved ? 'Bookmarked' : 'Bookmark Article'}</span>
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={pending}
      aria-pressed={saved}
      aria-label={saved ? `Remove bookmark for ${article.title}` : `Bookmark ${article.title}`}
      title={saved ? 'Remove bookmark' : 'Save bookmark'}
      className={`inline-flex h-10 w-10 items-center justify-center rounded-md border transition-colors duration-150 shrink-0 cursor-pointer disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F1E36] dark:focus-visible:outline-amber-400 ${
        saved
          ? 'border-amber-600/40 bg-amber-50 text-amber-700 hover:bg-amber-100 dark:border-amber-500/40 dark:bg-amber-950/60 dark:text-amber-300 dark:hover:bg-amber-900/60'
          : 'border-stone-200 bg-white text-stone-600 hover:border-stone-300 hover:text-stone-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-slate-600 dark:hover:text-white'
      }`}
    >
      <Bookmark
        className={`h-4 w-4 ${saved ? 'fill-amber-600 dark:fill-amber-400' : ''}`}
        aria-hidden="true"
      />
    </button>
  );
}
