import type { CategoryId, CategoryMeta } from '../types/news';

export const CATEGORIES: CategoryMeta[] = [
  {
    id: 'all',
    label: 'All News',
    description: 'Latest headlines aggregated across every desk and beat.',
  },
  {
    id: 'general',
    label: 'General',
    description: 'Global affairs, civic policy, and breaking front-page coverage.',
  },
  {
    id: 'technology',
    label: 'Technology',
    description: 'Artificial intelligence, computing hardware, and software ecosystems.',
  },
  {
    id: 'business',
    label: 'Business',
    description: 'Markets, macroeconomics, trade, and corporate reporting.',
  },
  {
    id: 'sports',
    label: 'Sports',
    description: 'International cricket, football, athletics, and tournament fixtures.',
  },
  {
    id: 'entertainment',
    label: 'Entertainment',
    description: 'Cinema, visual arts, literature, and cultural criticism.',
  },
  {
    id: 'health',
    label: 'Health',
    description: 'Public health, clinical research, nutrition, and medical breakthroughs.',
  },
  {
    id: 'science',
    label: 'Science',
    description: 'Space exploration, climate science, physics, and discovery.',
  },
];

export const SEARCH_SUGGESTIONS = [
  'Artificial Intelligence',
  'Latest Technology',
  'Cricket',
  'Indian Economy',
];

export const NEWSROOM_HERO_IMAGE = '/src/assets/images/editorial_newsroom_1794899689221.jpg';

const CATEGORY_FALLBACK_IMAGES: Record<Exclude<CategoryId, 'all'>, string> = {
  general: '/src/assets/images/editorial_newsroom_1794899689221.jpg',
  technology: '/src/assets/images/fallback_technology_1794899688827.jpg',
  business: '/src/assets/images/fallback_business_world_1794899689682.jpg',
  sports: '/src/assets/images/fallback_business_world_1794899689682.jpg',
  entertainment: '/src/assets/images/editorial_newsroom_1794899689221.jpg',
  health: '/src/assets/images/fallback_science_health_1794899689910.jpg',
  science: '/src/assets/images/fallback_science_health_1794899689910.jpg',
};

export function getFallbackImage(category: CategoryId): string {
  if (category === 'all') {
    return NEWSROOM_HERO_IMAGE;
  }
  return CATEGORY_FALLBACK_IMAGES[category] ?? NEWSROOM_HERO_IMAGE;
}

export function getCategoryLabel(category: CategoryId): string {
  return CATEGORIES.find((c) => c.id === category)?.label ?? 'General';
}

export function formatPublishedDate(isoDate: string): string {
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) {
    return 'Recent';
  }
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(date);
}

export function formatDateTime(isoDate: string): string {
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) {
    return 'Recently published';
  }
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}
