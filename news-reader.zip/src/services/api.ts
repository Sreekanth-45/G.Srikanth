import type { Article, ArticleNote, Bookmark, CategoryId, NewsFeedResponse } from '../types/news';

async function handleJson<T>(response: Response): Promise<T> {
  const data = (await response.json().catch(() => ({}))) as T & { error?: string };
  if (!response.ok) {
    throw new Error(data.error || `Request failed with status ${response.status}`);
  }
  return data;
}

export async function fetchNews(options: {
  category: CategoryId;
  query: string;
}): Promise<NewsFeedResponse> {
  const params = new URLSearchParams();
  params.set('category', options.category);
  if (options.query.trim()) {
    params.set('q', options.query.trim());
  }
  const res = await fetch(`/api/news?${params.toString()}`);
  return handleJson<NewsFeedResponse>(res);
}

export async function fetchArticleById(id: string): Promise<Article> {
  const res = await fetch(`/api/articles/${encodeURIComponent(id)}`);
  const data = await handleJson<{ article: Article }>(res);
  return data.article;
}

export async function fetchBookmarks(): Promise<Bookmark[]> {
  const res = await fetch('/api/bookmarks');
  const data = await handleJson<{ bookmarks: Bookmark[] }>(res);
  return data.bookmarks;
}

export async function saveBookmark(
  article: Article,
): Promise<{ bookmark: Bookmark; alreadyExists: boolean }> {
  const res = await fetch('/api/bookmarks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ article }),
  });
  return handleJson<{ bookmark: Bookmark; alreadyExists: boolean }>(res);
}

export async function deleteBookmark(id: string): Promise<void> {
  const res = await fetch(`/api/bookmarks/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
  await handleJson<{ removed: boolean }>(res);
}

export async function fetchNotes(articleId?: string): Promise<ArticleNote[]> {
  const url = articleId
    ? `/api/notes?articleId=${encodeURIComponent(articleId)}`
    : '/api/notes';
  const res = await fetch(url);
  const data = await handleJson<{ notes: ArticleNote[] }>(res);
  return data.notes;
}

export async function createArticleNote(input: {
  articleId: string;
  articleUrl: string;
  articleTitle: string;
  noteContent: string;
}): Promise<ArticleNote> {
  const res = await fetch('/api/notes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
  const data = await handleJson<{ note: ArticleNote }>(res);
  return data.note;
}

export async function updateArticleNote(id: number, noteContent: string): Promise<ArticleNote> {
  const res = await fetch(`/api/notes/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ noteContent }),
  });
  const data = await handleJson<{ note: ArticleNote }>(res);
  return data.note;
}

export async function deleteArticleNote(id: number): Promise<void> {
  const res = await fetch(`/api/notes/${id}`, {
    method: 'DELETE',
  });
  await handleJson<{ deleted: boolean }>(res);
}
