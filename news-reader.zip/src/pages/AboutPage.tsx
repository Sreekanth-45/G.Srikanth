import { Link } from 'react-router-dom';
import { NEWSROOM_HERO_IMAGE } from '../utils/formatters';

const TECHNOLOGIES = [
  {
    name: 'React & React Router',
    role: 'Modular component UI, client-side routing across Feed, Categories, Article Details, Bookmarks, and About views.',
  },
  {
    name: 'Tailwind CSS',
    role: 'Responsive utility styling with editorial typography and synchronized light/dark theme support.',
  },
  {
    name: 'Node.js & Express',
    role: 'RESTful backend server handling API proxying, key protection, RSS/JSON aggregation, and database CRUD routes.',
  },
  {
    name: 'SQLite (node:sqlite)',
    role: 'Embedded relational database persisting bookmarks, personal notes, and article metadata locally across restarts.',
  },
  {
    name: 'NewsAPI.org & Public Feeds',
    role: 'Supports NewsAPI.org via secure server-side environment variables with automatic fallback to live public RSS/JSON feeds.',
  },
  {
    name: 'Lucide React',
    role: 'Accessible, lightweight vector iconography for interactive controls and navigation cues.',
  },
];

const FEATURES = [
  'Live headline aggregation across General, Technology, Business, Sports, Entertainment, Health, and Science desks.',
  'Keyword search supporting multi-word topics such as Artificial Intelligence, Cricket, or Indian Economy.',
  'Dedicated Article Details reading view with attribution, external publisher link, and resilient imagery.',
  'Duplicate-safe Bookmarking backed by SQLite so saved stories persist across browser refreshes.',
  'Full CRUD Personal Notes per article (create, read, edit, and delete) with automatic article title population.',
  'Responsive mobile, tablet, and desktop layouts with loading, empty, and error states plus a dark mode toggle.',
];

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="overflow-hidden rounded-lg border border-stone-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="grid grid-cols-1 items-stretch lg:grid-cols-12">
          <div className="p-6 sm:p-8 lg:col-span-7">
            <p className="text-xs font-semibold uppercase tracking-widest text-[#9A3412] dark:text-amber-400">
              College Laboratory Project
            </p>
            <h1 className="mt-2 font-editorial font-serif text-3xl font-bold text-stone-900 sm:text-4xl dark:text-slate-50">
              News Reader
            </h1>
            <p className="mt-4 text-base leading-relaxed text-stone-700 dark:text-slate-300">
              News Reader is a full-stack personal news reading application designed and developed
              as a college laboratory submission to demonstrate modern frontend engineering, backend
              API integration, and persistent relational database operations.
            </p>
            <p className="mt-3 text-sm leading-relaxed text-stone-600 dark:text-slate-400">
              Users can browse live news from seven editorial categories, search stories by
              keyword, inspect full article details, save articles into a personal reading list, and
              maintain study or reading notes linked to individual articles.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                to="/"
                className="inline-flex items-center rounded-md bg-[#0F1E36] px-4 py-2 text-sm font-medium text-white hover:bg-[#193055] dark:bg-amber-600 dark:hover:bg-amber-500"
              >
                Explore News Feed
              </Link>
              <Link
                to="/bookmarks"
                className="inline-flex items-center rounded-md border border-stone-300 bg-white px-4 py-2 text-sm font-medium text-stone-800 hover:bg-stone-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
              >
                View Saved Bookmarks
              </Link>
            </div>
          </div>

          <div className="bg-stone-100 lg:col-span-5 dark:bg-slate-800">
            <img
              src={NEWSROOM_HERO_IMAGE}
              alt="Broadsheet newspaper and study desk for News Reader project"
              className="aspect-[16/10] w-full object-cover lg:h-full lg:aspect-auto"
            />
          </div>
        </div>
      </div>

      <section className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-2">
        <div className="rounded-lg border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-slate-50">
            Purpose of the Project
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-stone-600 dark:text-slate-300">
            The goal of this application is to combine real-world public news syndication with
            personal knowledge management in a clean, maintainable codebase suitable for academic
            evaluation. It illustrates how an Express backend protects API credentials, normalizes
            external feeds, and exposes REST endpoints backed by SQLite tables.
          </p>
        </div>

        <div className="rounded-lg border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-slate-50">
            API Integration &amp; Free-Tier Notes
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-stone-600 dark:text-slate-300">
            NewsAPI.org’s free Developer tier permits localhost requests up to 100 calls per day and
            blocks direct browser or production-host calls (HTTP 426). To keep API keys secure and
            ensure reliable operation everywhere, News Reader routes all requests through the
            Node.js server and automatically uses live public RSS/JSON news feeds whenever{' '}
            <code className="rounded bg-stone-100 px-1.5 py-0.5 text-xs dark:bg-slate-800">
              NEWS_API_KEY
            </code>{' '}
            is unset or rate-limited.
          </p>
        </div>
      </section>

      <section className="mt-10 rounded-lg border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-slate-50">
          Main Features
        </h2>
        <ul className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {FEATURES.map((feature, index) => (
            <li
              key={feature}
              className="border-b border-stone-100 pb-3 text-sm leading-relaxed text-stone-700 last:border-b-0 dark:border-slate-800 dark:text-slate-300"
            >
              <span className="mr-2 font-semibold text-[#9A3412] tabular-nums dark:text-amber-400">
                0{index + 1}.
              </span>
              {feature}
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-10">
        <h2 className="font-serif text-2xl font-bold text-stone-900 dark:text-slate-50">
          Technologies Used
        </h2>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {TECHNOLOGIES.map((tech) => (
            <div
              key={tech.name}
              className="rounded-lg border border-stone-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
            >
              <h3 className="font-serif text-base font-bold text-stone-900 dark:text-slate-100">
                {tech.name}
              </h3>
              <p className="mt-1.5 text-xs leading-relaxed text-stone-600 dark:text-slate-400">
                {tech.role}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
