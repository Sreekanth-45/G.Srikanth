import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import NewsFeed from '../components/NewsFeed';
import { fetchNews } from '../services/api';
import type { Article, CategoryId } from '../types/news';
import { CATEGORIES } from '../utils/formatters';

export default function CategoriesPage() {
  const categoryDesks = CATEGORIES.filter((c) => c.id !== 'all');
  const [activeCategory, setActiveCategory] = useState<CategoryId>('technology');
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadCategory = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetchNews({ category: activeCategory, query: '' });
      setArticles(res.articles);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load category articles.');
      setArticles([]);
    } finally {
      setLoading(false);
    }
  }, [activeCategory]);

  useEffect(() => {
    void loadCategory();
  }, [loadCategory]);

  const currentDesk = categoryDesks.find((c) => c.id === activeCategory);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex flex-col justify-between gap-4 border-b border-stone-200 pb-6 sm:flex-row sm:items-end dark:border-slate-800">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-[#9A3412] dark:text-amber-400">
            News Desks
          </p>
          <h1 className="mt-1 font-editorial font-serif text-3xl font-bold text-stone-900 sm:text-4xl dark:text-slate-50">
            Browse by Category
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-stone-600 dark:text-slate-300">
            Select any editorial desk below to fetch live coverage, or return to the combined front
            page.
          </p>
        </div>

        <Link
          to="/"
          className="inline-flex items-center justify-center rounded-md border border-stone-300 bg-white px-4 py-2 text-sm font-medium text-stone-800 transition-colors hover:bg-stone-100 whitespace-nowrap shrink-0 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
        >
          Return to All News
        </Link>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {categoryDesks.map((desk) => {
          const isSelected = desk.id === activeCategory;
          return (
            <button
              key={desk.id}
              type="button"
              onClick={() => setActiveCategory(desk.id)}
              aria-pressed={isSelected}
              className={`flex flex-col items-start rounded-lg border p-4 text-left transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F1E36] ${
                isSelected
                  ? 'border-[#0F1E36] bg-[#0F1E36] text-white dark:border-amber-500 dark:bg-amber-600'
                  : 'border-stone-200 bg-white text-stone-900 hover:border-stone-300 hover:bg-stone-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100 dark:hover:border-slate-700 dark:hover:bg-slate-800'
              }`}
            >
              <span className="font-serif text-lg font-bold">{desk.label}</span>
              <span
                className={`mt-1 text-xs leading-relaxed ${
                  isSelected ? 'text-slate-200 dark:text-amber-50' : 'text-stone-500 dark:text-slate-400'
                }`}
              >
                {desk.description}
              </span>
            </button>
          );
        })}
      </div>

      <section className="mt-10">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 pb-3 dark:border-slate-800">
          <h2 className="font-serif text-2xl font-bold text-stone-900 dark:text-slate-50">
            {currentDesk?.label} Headlines
          </h2>
          <Link
            to={`/?category=${activeCategory}`}
            className="text-xs font-semibold text-[#0F1E36] underline underline-offset-4 hover:text-[#193055] dark:text-amber-400 dark:hover:text-amber-300"
          >
            Open {currentDesk?.label} in Home Feed
          </Link>
        </div>

        <NewsFeed
          articles={articles}
          loading={loading}
          error={error}
          onRetry={loadCategory}
          showFeatured={false}
        />
      </section>
    </div>
  );
}
