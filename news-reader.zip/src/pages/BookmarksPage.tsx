import { ArrowRight, BookmarkX, ExternalLink, FileText, Newspaper } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import ArticleImage from '../components/ArticleImage';
import { useNewsReader } from '../context/NewsReaderContext';
import { fetchNotes } from '../services/api';
import type { ArticleNote } from '../types/news';
import { formatPublishedDate, getCategoryLabel } from '../utils/formatters';

export default function BookmarksPage() {
  const { bookmarks, bookmarksLoading, removeBookmarkById } = useNewsReader();
  const [notesByArticle, setNotesByArticle] = useState<Record<string, number>>({});
  const [removingId, setRemovingId] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function loadNotesCounts() {
      try {
        const allNotes: ArticleNote[] = await fetchNotes();
        if (cancelled) return;
        const counts: Record<string, number> = {};
        for (const n of allNotes) {
          counts[n.articleId] = (counts[n.articleId] ?? 0) + 1;
        }
        setNotesByArticle(counts);
      } catch {
        // Non-blocking metadata count.
      }
    }
    void loadNotesCounts();
    return () => {
      cancelled = true;
    };
  }, [bookmarks.length]);

  const handleRemove = async (id: string) => {
    try {
      setRemovingId(id);
      await removeBookmarkById(id);
    } finally {
      setRemovingId(null);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex flex-col justify-between gap-4 border-b border-stone-200 pb-6 sm:flex-row sm:items-end dark:border-slate-800">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-[#9A3412] dark:text-amber-400">
            Personal Reading List
          </p>
          <h1 className="mt-1 font-editorial font-serif text-3xl font-bold text-stone-900 sm:text-4xl dark:text-slate-50">
            Saved Bookmarks
          </h1>
          <p className="mt-2 text-sm text-stone-600 dark:text-slate-300">
            Articles you save are stored persistently in SQLite and remain available across sessions.
          </p>
        </div>

        <p className="text-xs font-medium text-stone-500 tabular-nums dark:text-slate-400">
          {bookmarks.length} {bookmarks.length === 1 ? 'saved article' : 'saved articles'}
        </p>
      </div>

      <section className="mt-8">
        {bookmarksLoading ? (
          <p className="py-12 text-center text-sm text-stone-500 dark:text-slate-400">
            Loading saved bookmarks...
          </p>
        ) : bookmarks.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-lg border border-stone-200 bg-white px-6 py-16 text-center dark:border-slate-800 dark:bg-slate-900">
            <Newspaper className="mb-3 h-9 w-9 text-stone-400 dark:text-slate-500" aria-hidden="true" />
            <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-slate-100">
              No Bookmarked Articles Yet
            </h2>
            <p className="mt-2 max-w-md text-sm text-stone-600 dark:text-slate-400">
              Click the bookmark icon on any news story to save it here for later reading and note
              taking.
            </p>
            <Link
              to="/"
              className="mt-5 inline-flex items-center gap-2 rounded-md bg-[#0F1E36] px-4 py-2 text-sm font-medium text-white hover:bg-[#193055] dark:bg-amber-600 dark:hover:bg-amber-500"
            >
              <span>Browse Latest News</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {bookmarks.map((bookmark) => {
              const noteCount = notesByArticle[bookmark.id] ?? 0;
              return (
                <article
                  key={bookmark.id}
                  className="flex h-full flex-col overflow-hidden rounded-lg border border-stone-200 bg-white dark:border-slate-800 dark:bg-slate-900"
                >
                  <Link
                    to={`/article/${bookmark.id}`}
                    state={{ article: bookmark }}
                    className="block overflow-hidden bg-stone-100 dark:bg-slate-800"
                  >
                    <ArticleImage
                      src={bookmark.imageUrl}
                      alt={bookmark.title}
                      category={bookmark.category}
                      className="aspect-[4/3] w-full"
                    />
                  </Link>

                  <div className="flex flex-1 flex-col justify-between p-5">
                    <div className="space-y-2.5">
                      <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium text-stone-500 tabular-nums dark:text-slate-400">
                        <span className="text-[#9A3412] dark:text-amber-400">
                          {getCategoryLabel(bookmark.category)}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{bookmark.source}</span>
                        <span aria-hidden="true">·</span>
                        <time dateTime={bookmark.publishedAt}>
                          {formatPublishedDate(bookmark.publishedAt)}
                        </time>
                      </div>

                      <h2 className="font-editorial font-serif text-lg font-bold leading-snug text-stone-900 dark:text-slate-50">
                        <Link
                          to={`/article/${bookmark.id}`}
                          state={{ article: bookmark }}
                          className="hover:text-[#0F1E36] dark:hover:text-amber-300 transition-colors"
                        >
                          {bookmark.title}
                        </Link>
                      </h2>

                      {noteCount > 0 && (
                        <p className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-600 tabular-nums dark:text-slate-300">
                          <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>
                            {noteCount} personal {noteCount === 1 ? 'note' : 'notes'} saved
                          </span>
                        </p>
                      )}
                    </div>

                    <div className="mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-stone-100 pt-4 dark:border-slate-800">
                      <div className="flex items-center gap-2">
                        <Link
                          to={`/article/${bookmark.id}`}
                          state={{ article: bookmark }}
                          className="inline-flex items-center gap-1.5 rounded-md bg-[#0F1E36] px-3 py-2 text-xs font-medium text-white hover:bg-[#193055] whitespace-nowrap shrink-0 dark:bg-amber-600 dark:hover:bg-amber-500"
                        >
                          <span>Read &amp; Notes</span>
                          <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                        </Link>

                        <a
                          href={bookmark.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label={`Open original article: ${bookmark.title}`}
                          className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-stone-300 text-stone-600 hover:bg-stone-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                        >
                          <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                        </a>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemove(bookmark.id)}
                        disabled={removingId === bookmark.id}
                        className="inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700 transition-colors hover:bg-red-100 disabled:opacity-50 cursor-pointer whitespace-nowrap shrink-0 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300 dark:hover:bg-red-900/50"
                      >
                        <BookmarkX className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Remove</span>
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
