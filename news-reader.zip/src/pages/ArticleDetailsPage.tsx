import { ArrowLeft, ExternalLink, Loader2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import ArticleImage from '../components/ArticleImage';
import BookmarkButton from '../components/BookmarkButton';
import NotesForm from '../components/NotesForm';
import { fetchArticleById } from '../services/api';
import type { Article } from '../types/news';
import { formatDateTime, getCategoryLabel } from '../utils/formatters';

interface LocationState {
  article?: Article;
}

export default function ArticleDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const stateArticle = (location.state as LocationState | null)?.article ?? null;

  const [article, setArticle] = useState<Article | null>(stateArticle);
  const [loading, setLoading] = useState(!stateArticle);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (stateArticle && stateArticle.id === id) {
      setArticle(stateArticle);
      setLoading(false);
      setError(null);
      return;
    }

    if (!id) {
      setError('Invalid article identifier.');
      setLoading(false);
      return;
    }

    let cancelled = false;
    async function load() {
      try {
        setLoading(true);
        setError(null);
        const fetched = await fetchArticleById(id as string);
        if (!cancelled) setArticle(fetched);
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof Error
              ? err.message
              : 'This article could not be loaded. Return to the news feed to select a story.',
          );
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [id, stateArticle]);

  if (loading) {
    return (
      <div className="mx-auto flex max-w-4xl flex-col items-center justify-center px-4 py-24 text-center">
        <Loader2
          className="mb-3 h-8 w-8 animate-spin text-[#0F1E36] dark:text-amber-400"
          aria-hidden="true"
        />
        <p className="text-sm font-medium text-stone-600 dark:text-slate-300">
          Loading article details...
        </p>
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <div className="rounded-lg border border-stone-200 bg-white p-10 dark:border-slate-800 dark:bg-slate-900">
          <h1 className="font-serif text-2xl font-bold text-stone-900 dark:text-slate-50">
            Article Unavailable
          </h1>
          <p className="mt-2 text-sm text-stone-600 dark:text-slate-300">
            {error || 'We could not locate this article.'}
          </p>
          <Link
            to="/"
            className="mt-6 inline-flex items-center gap-2 rounded-md bg-[#0F1E36] px-4 py-2 text-sm font-medium text-white hover:bg-[#193055] dark:bg-amber-600 dark:hover:bg-amber-500"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            <span>Back to News</span>
          </Link>
        </div>
      </div>
    );
  }

  const categoryLabel = getCategoryLabel(article.category);
  const hasExtendedContent =
    article.content && article.content !== article.description && article.content.length > 0;

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <button
          type="button"
          onClick={() => {
            if (window.history.length > 1) {
              navigate(-1);
            } else {
              navigate('/');
            }
          }}
          className="inline-flex items-center gap-2 rounded-md border border-stone-300 bg-white px-4 py-2 text-sm font-medium text-stone-800 transition-colors hover:bg-stone-100 cursor-pointer dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Back to News</span>
        </button>

        <BookmarkButton article={article} variant="button" />
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-12">
        <article className="lg:col-span-7">
          <header className="space-y-4 border-b border-stone-200 pb-6 dark:border-slate-800">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-stone-500 tabular-nums dark:text-slate-400">
              <span className="font-semibold text-[#9A3412] dark:text-amber-400">
                {categoryLabel}
              </span>
              <span aria-hidden="true">·</span>
              <span>{article.source}</span>
              {article.author && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>By {article.author}</span>
                </>
              )}
              <span aria-hidden="true">·</span>
              <time dateTime={article.publishedAt}>{formatDateTime(article.publishedAt)}</time>
            </div>

            <h1 className="font-editorial font-serif text-3xl font-bold leading-tight text-stone-900 sm:text-4xl dark:text-slate-50">
              {article.title}
            </h1>
          </header>

          <figure className="mt-6 overflow-hidden rounded-lg border border-stone-200 bg-stone-100 dark:border-slate-800 dark:bg-slate-900">
            <ArticleImage
              src={article.imageUrl}
              alt={article.title}
              category={article.category}
              className="aspect-[16/9] w-full"
            />
            <figcaption className="border-t border-stone-200 bg-white px-4 py-2.5 text-xs italic text-stone-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
              Source: {article.source}
              {article.author ? ` · Reported by ${article.author}` : ''}
            </figcaption>
          </figure>

          <div className="mt-6 max-w-prose space-y-5 text-base leading-relaxed text-stone-800 dark:text-slate-200">
            {article.description ? (
              <p className="text-lg font-medium leading-relaxed text-stone-900 dark:text-slate-100">
                {article.description}
              </p>
            ) : (
              <p className="text-stone-600 dark:text-slate-400">
                The publisher did not include a summary excerpt in the syndication feed.
              </p>
            )}

            {hasExtendedContent && (
              <p className="leading-relaxed text-stone-700 dark:text-slate-300">
                {article.content}
              </p>
            )}

            <div className="rounded-lg border border-stone-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <p className="text-xs font-semibold uppercase tracking-wider text-stone-500 dark:text-slate-400">
                Publisher Attribution
              </p>
              <p className="mt-1.5 text-sm text-stone-600 dark:text-slate-300">
                Public news feeds provide article summaries. Use the link below to read the complete
                report directly on {article.source}.
              </p>
              <p className="mt-2 truncate text-xs text-stone-500 dark:text-slate-400">
                Original URL:{' '}
                <a
                  href={article.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline hover:text-stone-900 dark:hover:text-slate-100"
                >
                  {article.url}
                </a>
              </p>
              <div className="mt-4">
                <a
                  href={article.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-md bg-[#0F1E36] px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#193055] dark:bg-amber-600 dark:hover:bg-amber-500"
                >
                  <span>Read Full Article</span>
                  <ExternalLink className="h-4 w-4" aria-hidden="true" />
                </a>
              </div>
            </div>
          </div>
        </article>

        <aside className="lg:col-span-5">
          <div className="lg:sticky lg:top-6">
            <NotesForm
              articleId={article.id}
              articleUrl={article.url}
              articleTitle={article.title}
            />
          </div>
        </aside>
      </div>
    </div>
  );
}
