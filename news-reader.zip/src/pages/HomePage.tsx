import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import CategoryFilter from '../components/CategoryFilter';
import NewsFeed from '../components/NewsFeed';
import SearchBar from '../components/SearchBar';
import { fetchNews } from '../services/api';
import type { Article, CategoryId } from '../types/news';
import { CATEGORIES, getCategoryLabel } from '../utils/formatters';

function parseCategoryParam(raw: string | null): CategoryId {
  const valid = CATEGORIES.map((c) => c.id);
  if (raw && valid.includes(raw as CategoryId)) {
    return raw as CategoryId;
  }
  return 'all';
}

export default function HomePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedCategory = parseCategoryParam(searchParams.get('category'));
  const query = searchParams.get('q') ?? '';

  const [articles, setArticles] = useState<Article[]>([]);
  const [provider, setProvider] = useState<string>('');
  const [notice, setNotice] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadFeed = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchNews({ category: selectedCategory, query });
      setArticles(data.articles);
      setProvider(data.provider);
      setNotice(data.notice);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Unable to fetch news articles right now. Please try again.',
      );
      setArticles([]);
    } finally {
      setLoading(false);
    }
  }, [selectedCategory, query]);

  useEffect(() => {
    void loadFeed();
  }, [loadFeed]);

  const handleSelectCategory = (category: CategoryId) => {
    const next = new URLSearchParams(searchParams);
    if (category === 'all') {
      next.delete('category');
    } else {
      next.set('category', category);
    }
    setSearchParams(next);
  };

  const handleSearch = (nextQuery: string) => {
    const next = new URLSearchParams(searchParams);
    if (nextQuery) {
      next.set('q', nextQuery);
    } else {
      next.delete('q');
    }
    setSearchParams(next);
  };

  const handleClearSearch = () => {
    const next = new URLSearchParams(searchParams);
    next.delete('q');
    setSearchParams(next);
  };

  const handleResetFilters = () => {
    setSearchParams({});
  };

  const activeCategoryLabel = getCategoryLabel(selectedCategory);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <section className="space-y-6 border-b border-stone-200 pb-6 dark:border-slate-800">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-[#9A3412] dark:text-amber-400">
              {query ? 'Keyword Search Results' : activeCategoryLabel}
            </p>
            <h1 className="mt-1 font-editorial font-serif text-3xl font-bold tracking-tight text-stone-900 sm:text-4xl dark:text-slate-50">
              {query ? `Stories matching “${query}”` : 'Today’s News Edition'}
            </h1>
          </div>

          {!loading && !error && (
            <div className="text-xs text-stone-500 tabular-nums dark:text-slate-400">
              <span>{articles.length} articles</span>
              {provider && (
                <>
                  <span aria-hidden="true"> · </span>
                  <span>Source: {provider}</span>
                </>
              )}
            </div>
          )}
        </div>

        <SearchBar query={query} onSearch={handleSearch} onClear={handleClearSearch} />

        <CategoryFilter
          selectedCategory={selectedCategory}
          onSelectCategory={handleSelectCategory}
        />

        {notice && (
          <p className="rounded-md border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900 dark:border-amber-900/60 dark:bg-amber-950/40 dark:text-amber-200">
            {notice}
          </p>
        )}
      </section>

      <section className="mt-8">
        <NewsFeed
          articles={articles}
          loading={loading}
          error={error}
          onRetry={loadFeed}
          onResetFilters={
            selectedCategory !== 'all' || query ? handleResetFilters : undefined
          }
          showFeatured={selectedCategory === 'all' && !query}
        />
      </section>
    </div>
  );
}
