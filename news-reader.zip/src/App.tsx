import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import { NewsReaderProvider } from './context/NewsReaderContext';
import AboutPage from './pages/AboutPage';
import ArticleDetailsPage from './pages/ArticleDetailsPage';
import BookmarksPage from './pages/BookmarksPage';
import CategoriesPage from './pages/CategoriesPage';
import HomePage from './pages/HomePage';

export default function App() {
  return (
    <NewsReaderProvider>
      <BrowserRouter>
        <div className="flex min-h-screen flex-col bg-[#FBF9F5] text-stone-900 transition-colors duration-150 dark:bg-slate-950 dark:text-slate-100">
          <Navbar />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/categories" element={<CategoriesPage />} />
              <Route path="/article/:id" element={<ArticleDetailsPage />} />
              <Route path="/bookmarks" element={<BookmarksPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="*" element={<HomePage />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </NewsReaderProvider>
  );
}
