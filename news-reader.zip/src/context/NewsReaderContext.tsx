import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { deleteBookmark, fetchBookmarks, saveBookmark } from '../services/api';
import type { Article, Bookmark } from '../types/news';

interface NewsReaderContextValue {
  bookmarks: Bookmark[];
  bookmarksLoading: boolean;
  isBookmarked: (articleId: string) => boolean;
  toggleBookmark: (article: Article) => Promise<'added' | 'removed'>;
  removeBookmarkById: (articleId: string) => Promise<void>;
  refreshBookmarks: () => Promise<void>;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const NewsReaderContext = createContext<NewsReaderContextValue | undefined>(undefined);

export function NewsReaderProvider({ children }: { children: ReactNode }) {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [bookmarksLoading, setBookmarksLoading] = useState(true);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      return localStorage.getItem('news-reader-theme') === 'dark' ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem('news-reader-theme', theme);
    } catch {
      // Ignore storage write errors in restricted contexts.
    }
  }, [theme]);

  const refreshBookmarks = useCallback(async () => {
    try {
      setBookmarksLoading(true);
      const list = await fetchBookmarks();
      setBookmarks(list);
    } catch {
      // Keep existing bookmarks if backend check fails transiently.
    } finally {
      setBookmarksLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshBookmarks();
  }, [refreshBookmarks]);

  const isBookmarked = useCallback(
    (articleId: string) => bookmarks.some((b) => b.id === articleId),
    [bookmarks],
  );

  const toggleBookmark = useCallback(
    async (article: Article): Promise<'added' | 'removed'> => {
      const exists = bookmarks.some((b) => b.id === article.id || b.url === article.url);
      if (exists) {
        const target = bookmarks.find((b) => b.id === article.id || b.url === article.url);
        const targetId = target?.id ?? article.id;
        await deleteBookmark(targetId);
        setBookmarks((prev) => prev.filter((b) => b.id !== targetId));
        return 'removed';
      }

      const { bookmark, alreadyExists } = await saveBookmark(article);
      if (!alreadyExists) {
        setBookmarks((prev) => [bookmark, ...prev.filter((b) => b.id !== bookmark.id)]);
      }
      return 'added';
    },
    [bookmarks],
  );

  const removeBookmarkById = useCallback(async (articleId: string) => {
    await deleteBookmark(articleId);
    setBookmarks((prev) => prev.filter((b) => b.id !== articleId));
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  return (
    <NewsReaderContext.Provider
      value={{
        bookmarks,
        bookmarksLoading,
        isBookmarked,
        toggleBookmark,
        removeBookmarkById,
        refreshBookmarks,
        theme,
        toggleTheme,
      }}
    >
      {children}
    </NewsReaderContext.Provider>
  );
}

export function useNewsReader() {
  const ctx = useContext(NewsReaderContext);
  if (!ctx) {
    throw new Error('useNewsReader must be used inside NewsReaderProvider');
  }
  return ctx;
}
