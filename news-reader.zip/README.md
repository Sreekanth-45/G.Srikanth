# News Reader — Personal News Reading Application

A full-stack personal news reading web application built for a college laboratory submission. Users can browse live news articles across seven categories, search by keyword, inspect full article details, bookmark stories persistently, and write, edit, and delete personal reading notes per article.

## Technology Stack

- **Frontend:** React, React Router, TypeScript, Tailwind CSS, Lucide React
- **Backend:** Node.js, Express.js (`server.ts`)
- **Database:** SQLite via Node.js built-in `node:sqlite` (`data/news_reader.db`)
- **News API Integration:** NewsAPI.org (via server-side `NEWS_API_KEY`) with automatic live public RSS/JSON feed aggregation (BBC News, The New York Times, TechCrunch, The Hindu Economy, ESPNcricinfo, Spaceflight News API, and Hacker News Wire)

## Features

1. **Home News Feed:** Responsive editorial layout featuring a lead story spotlight and multi-column article grid with images, source, category, publication date, summary, Read More navigation, and bookmark controls.
2. **News Categories:** Filter dynamically across General, Technology, Business, Sports, Entertainment, Health, and Science, or return to All News. Dedicated Categories view included.
3. **Keyword Search:** Search across live news sources using keywords (for example: *Artificial Intelligence*, *Latest Technology*, *Cricket*, or *Indian Economy*) with a one-click Clear control.
4. **Article Details Page:** Displays full title, image, source, author (when available), publication date and time, description/content, original publisher URL, external **Read Full Article** button, bookmark button, and **Back to News** navigation.
5. **Persistent Bookmarks:** Save and remove articles without duplicates. Stored in SQLite (`bookmarks` table) so bookmarks survive browser refreshes and server restarts.
6. **Personal Notes (Full CRUD):** Automatically populates the article title and lets users create, view, edit, and delete personal notes linked to each article (`notes` table).
7. **Dark Mode & Responsive Design:** Synchronized light/dark theme toggle and mobile-friendly navigation bar.

## Project Structure

```text
├── server.ts                  # Express server entry point & REST API routes
├── server/
│   ├── db.ts                  # SQLite database initialization and queries
│   └── newsService.ts         # NewsAPI.org & live public news feed aggregator
├── src/
│   ├── components/            # Navbar, NewsCard, NewsFeed, CategoryFilter, SearchBar,
│   │                          # BookmarkButton, NotesForm, ArticleImage, Footer
│   ├── context/               # NewsReaderContext (bookmarks & theme state)
│   ├── pages/                 # HomePage, CategoriesPage, ArticleDetailsPage,
│   │                          # BookmarksPage, AboutPage
│   ├── services/              # Frontend API client (src/services/api.ts)
│   ├── types/                 # TypeScript interfaces
│   ├── utils/                 # Category definitions, date formatters, fallbacks
│   ├── App.tsx                # Router & page layout
│   ├── index.css              # Tailwind CSS configuration & theme styles
│   └── main.tsx               # React entry point
├── .env.example               # Environment variable template
├── package.json
└── README.md
```

## Database Schema (SQLite)

- **`bookmarks`**: `id`, `url` (UNIQUE), `title`, `description`, `content`, `image_url`, `source`, `author`, `category`, `published_at`, `created_at`
- **`notes`**: `id` (AUTOINCREMENT), `article_id`, `article_url`, `article_title`, `note_content`, `created_at`, `updated_at`
- **`articles_cache`**: `id`, `payload`, `updated_at`

## News API Configuration & Free-Tier Notes

1. Create a free account at [https://newsapi.org/](https://newsapi.org/) and copy your API key.
2. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
3. Set your key in `.env`:
   ```env
   NEWS_API_KEY="your_newsapi_org_key_here"
   ```
4. **Important NewsAPI.org Developer Tier Restrictions:**
   - NewsAPI.org's free Developer plan is limited to **100 requests per day** and only permits requests originating from `localhost` (production/cloud hosts receive HTTP `426 Upgrade Required`).
   - All API calls in this project are executed securely on the Express backend (`server/newsService.ts`) so your `NEWS_API_KEY` is never exposed to the browser.
   - If `NEWS_API_KEY` is omitted, rate-limited, or restricted by host origin, the server automatically falls back to live public RSS/JSON feeds so the application remains 100% functional out of the box with real-time articles.

## Running the Project Locally

**Prerequisites:** Node.js v22.5+ (includes built-in `node:sqlite`).

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the development server (Express + Vite on port 3000):
   ```bash
   npm run dev
   ```
3. Open [http://localhost:3000](http://localhost:3000) in your browser.

### Production Build

```bash
npm run build
NODE_ENV=production npm start
```

## REST API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/news?category=all&q=` | Fetch live news articles by category and/or search query |
| `GET` | `/api/articles/:id` | Retrieve cached or bookmarked article details |
| `GET` | `/api/bookmarks` | List all saved bookmarks |
| `POST` | `/api/bookmarks` | Save a bookmark (duplicate URLs prevented) |
| `DELETE` | `/api/bookmarks/:id` | Remove a saved bookmark |
| `GET` | `/api/notes?articleId=` | Fetch personal notes (all or filtered by article) |
| `POST` | `/api/notes` | Create a personal note for an article |
| `PUT` | `/api/notes/:id` | Edit an existing personal note |
| `DELETE` | `/api/notes/:id` | Delete a personal note |
