import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import type { Article, ArticleNote, Bookmark, CategoryId } from '../src/types/news.ts';

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'news_reader.db');
const db = new DatabaseSync(dbPath);

db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS bookmarks (
    id TEXT PRIMARY KEY,
    url TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    content TEXT,
    image_url TEXT,
    source TEXT NOT NULL,
    author TEXT,
    category TEXT NOT NULL DEFAULT 'general',
    published_at TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id TEXT NOT NULL,
    article_url TEXT NOT NULL,
    article_title TEXT NOT NULL,
    note_content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_notes_article_id ON notes(article_id);

  CREATE TABLE IF NOT EXISTS articles_cache (
    id TEXT PRIMARY KEY,
    payload TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
`);

function normalizeCategory(value: unknown): Exclude<CategoryId, 'all'> {
  const valid: Array<Exclude<CategoryId, 'all'>> = [
    'general',
    'technology',
    'business',
    'sports',
    'entertainment',
    'health',
    'science',
  ];
  const str = String(value ?? 'general').toLowerCase();
  return (valid.includes(str as Exclude<CategoryId, 'all'>) ? str : 'general') as Exclude<
    CategoryId,
    'all'
  >;
}

interface BookmarkRow {
  id: string;
  url: string;
  title: string;
  description: string | null;
  content: string | null;
  image_url: string | null;
  source: string;
  author: string | null;
  category: string;
  published_at: string;
  created_at: string;
}

interface NoteRow {
  id: number;
  article_id: string;
  article_url: string;
  article_title: string;
  note_content: string;
  created_at: string;
  updated_at: string;
}

function mapBookmark(row: BookmarkRow): Bookmark {
  return {
    id: row.id,
    url: row.url,
    title: row.title,
    description: row.description,
    content: row.content,
    imageUrl: row.image_url,
    source: row.source,
    author: row.author,
    category: normalizeCategory(row.category),
    publishedAt: row.published_at,
    createdAt: row.created_at,
  };
}

function mapNote(row: NoteRow): ArticleNote {
  return {
    id: row.id,
    articleId: row.article_id,
    articleUrl: row.article_url,
    articleTitle: row.article_title,
    noteContent: row.note_content,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function cacheArticles(articles: Article[]): void {
  const stmt = db.prepare(`
    INSERT INTO articles_cache (id, payload, updated_at)
    VALUES (?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      payload = excluded.payload,
      updated_at = excluded.updated_at
  `);
  const now = new Date().toISOString();
  for (const article of articles) {
    stmt.run(article.id, JSON.stringify(article), now);
  }
}

export function getCachedArticleById(id: string): Article | null {
  const row = db
    .prepare('SELECT payload FROM articles_cache WHERE id = ?')
    .get(id) as { payload: string } | undefined;
  if (row) {
    try {
      return JSON.parse(row.payload) as Article;
    } catch {
      return null;
    }
  }

  const bookmarkRow = db
    .prepare('SELECT * FROM bookmarks WHERE id = ?')
    .get(id) as unknown as BookmarkRow | undefined;
  if (bookmarkRow) {
    const b = mapBookmark(bookmarkRow);
    return {
      id: b.id,
      title: b.title,
      description: b.description,
      content: b.content,
      url: b.url,
      imageUrl: b.imageUrl,
      source: b.source,
      author: b.author,
      category: b.category,
      publishedAt: b.publishedAt,
    };
  }
  return null;
}

export function listBookmarks(): Bookmark[] {
  const rows = db
    .prepare('SELECT * FROM bookmarks ORDER BY created_at DESC')
    .all() as unknown as BookmarkRow[];
  return rows.map(mapBookmark);
}

export function addBookmark(article: Article): { bookmark: Bookmark; alreadyExists: boolean } {
  const existing = db
    .prepare('SELECT * FROM bookmarks WHERE id = ? OR url = ?')
    .get(article.id, article.url) as unknown as BookmarkRow | undefined;

  if (existing) {
    return { bookmark: mapBookmark(existing), alreadyExists: true };
  }

  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO bookmarks (
      id, url, title, description, content, image_url,
      source, author, category, published_at, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    article.id,
    article.url,
    article.title,
    article.description ?? null,
    article.content ?? null,
    article.imageUrl ?? null,
    article.source || 'Unknown Source',
    article.author ?? null,
    normalizeCategory(article.category),
    article.publishedAt || now,
    now,
  );

  const inserted = db
    .prepare('SELECT * FROM bookmarks WHERE id = ?')
    .get(article.id) as unknown as BookmarkRow;
  return { bookmark: mapBookmark(inserted), alreadyExists: false };
}

export function removeBookmark(id: string): boolean {
  const result = db.prepare('DELETE FROM bookmarks WHERE id = ?').run(id);
  return Number(result.changes) > 0;
}

export function listNotes(articleId?: string): ArticleNote[] {
  if (articleId) {
    const rows = db
      .prepare('SELECT * FROM notes WHERE article_id = ? ORDER BY updated_at DESC')
      .all(articleId) as unknown as NoteRow[];
    return rows.map(mapNote);
  }
  const rows = db
    .prepare('SELECT * FROM notes ORDER BY updated_at DESC')
    .all() as unknown as NoteRow[];
  return rows.map(mapNote);
}

export function createNote(input: {
  articleId: string;
  articleUrl: string;
  articleTitle: string;
  noteContent: string;
}): ArticleNote {
  const now = new Date().toISOString();
  const result = db
    .prepare(`
      INSERT INTO notes (article_id, article_url, article_title, note_content, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `)
    .run(
      input.articleId,
      input.articleUrl,
      input.articleTitle,
      input.noteContent.trim(),
      now,
      now,
    );

  const created = db
    .prepare('SELECT * FROM notes WHERE id = ?')
    .get(Number(result.lastInsertRowid)) as unknown as NoteRow;
  return mapNote(created);
}

export function updateNote(id: number, noteContent: string): ArticleNote | null {
  const now = new Date().toISOString();
  const result = db
    .prepare('UPDATE notes SET note_content = ?, updated_at = ? WHERE id = ?')
    .run(noteContent.trim(), now, id);
  if (Number(result.changes) === 0) {
    return null;
  }
  const updated = db
    .prepare('SELECT * FROM notes WHERE id = ?')
    .get(id) as unknown as NoteRow;
  return mapNote(updated);
}

export function deleteNote(id: number): boolean {
  const result = db.prepare('DELETE FROM notes WHERE id = ?').run(id);
  return Number(result.changes) > 0;
}
