import crypto from 'node:crypto';
import { XMLParser } from 'fast-xml-parser';
import type { Article, CategoryId, NewsFeedResponse } from '../src/types/news.ts';
import { cacheArticles } from './db.ts';

type NewsCategory = Exclude<CategoryId, 'all'>;

interface FeedSource {
  url: string;
  source: string;
  category: NewsCategory;
}

const RSS_FEEDS: Record<NewsCategory, FeedSource[]> = {
  general: [
    { url: 'https://feeds.bbci.co.uk/news/rss.xml', source: 'BBC News', category: 'general' },
    {
      url: 'https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml',
      source: 'The New York Times',
      category: 'general',
    },
    { url: 'https://www.aljazeera.com/xml/rss/all.xml', source: 'Al Jazeera', category: 'general' },
  ],
  technology: [
    {
      url: 'https://feeds.bbci.co.uk/news/technology/rss.xml',
      source: 'BBC Technology',
      category: 'technology',
    },
    { url: 'https://techcrunch.com/feed/', source: 'TechCrunch', category: 'technology' },
    {
      url: 'https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml',
      source: 'NYT Technology',
      category: 'technology',
    },
  ],
  business: [
    {
      url: 'https://feeds.bbci.co.uk/news/business/rss.xml',
      source: 'BBC Business',
      category: 'business',
    },
    {
      url: 'https://www.thehindu.com/business/Economy/feeder/default.rss',
      source: 'The Hindu Economy',
      category: 'business',
    },
    {
      url: 'https://rss.nytimes.com/services/xml/rss/nyt/Business.xml',
      source: 'NYT Business',
      category: 'business',
    },
  ],
  sports: [
    { url: 'https://feeds.bbci.co.uk/sport/rss.xml', source: 'BBC Sport', category: 'sports' },
    {
      url: 'https://www.espncricinfo.com/rss/content/story/feeds/0.xml',
      source: 'ESPNcricinfo',
      category: 'sports',
    },
  ],
  entertainment: [
    {
      url: 'https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml',
      source: 'BBC Entertainment',
      category: 'entertainment',
    },
    {
      url: 'https://rss.nytimes.com/services/xml/rss/nyt/Arts.xml',
      source: 'NYT Arts & Culture',
      category: 'entertainment',
    },
  ],
  health: [
    { url: 'https://feeds.bbci.co.uk/news/health/rss.xml', source: 'BBC Health', category: 'health' },
    {
      url: 'https://rss.nytimes.com/services/xml/rss/nyt/Health.xml',
      source: 'NYT Health',
      category: 'health',
    },
  ],
  science: [
    {
      url: 'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml',
      source: 'BBC Science',
      category: 'science',
    },
    {
      url: 'https://rss.nytimes.com/services/xml/rss/nyt/Science.xml',
      source: 'NYT Science',
      category: 'science',
    },
  ],
};

const xmlParser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  textNodeName: '#text',
  trimValues: true,
});

const memoryCache = new Map<string, { expiresAt: number; data: NewsFeedResponse }>();
const CACHE_TTL_MS = 3 * 60 * 1000;

function createArticleId(url: string): string {
  return crypto.createHash('sha256').update(url).digest('hex').slice(0, 16);
}

function decodeHtmlEntities(input: string): string {
  return input
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'");
}

function cleanText(raw: unknown): string | null {
  if (!raw) return null;
  const text = typeof raw === 'string' ? raw : (raw as { '#text'?: string })['#text'] ?? '';
  if (!text) return null;
  const stripped = decodeHtmlEntities(text)
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return stripped.length > 0 ? stripped : null;
}

function upgradeImageResolution(url: string | null): string | null {
  if (!url || !/^https?:\/\//i.test(url)) return null;
  if (url.includes('ichef.bbci.co.uk/ace/standard/240/')) {
    return url.replace('/240/', '/800/');
  }
  return url;
}

function extractImageFromItem(item: Record<string, unknown>): string | null {
  const thumb = item['media:thumbnail'] as
    | { '@_url'?: string }
    | Array<{ '@_url'?: string }>
    | undefined;
  if (Array.isArray(thumb) && thumb[0]?.['@_url']) {
    return upgradeImageResolution(thumb[0]['@_url']);
  }
  if (thumb && !Array.isArray(thumb) && thumb['@_url']) {
    return upgradeImageResolution(thumb['@_url']);
  }

  const mediaContent = item['media:content'] as
    | { '@_url'?: string; '@_medium'?: string }
    | Array<{ '@_url'?: string; '@_medium'?: string }>
    | undefined;
  if (Array.isArray(mediaContent)) {
    const imgItem = mediaContent.find((m) => m['@_url']) ?? mediaContent[0];
    if (imgItem?.['@_url']) return upgradeImageResolution(imgItem['@_url']);
  } else if (mediaContent?.['@_url']) {
    return upgradeImageResolution(mediaContent['@_url']);
  }

  const enclosure = item['enclosure'] as
    | { '@_url'?: string; '@_type'?: string }
    | Array<{ '@_url'?: string; '@_type'?: string }>
    | undefined;
  if (Array.isArray(enclosure)) {
    const imgEnc = enclosure.find((e) => !e['@_type'] || e['@_type'].startsWith('image/'));
    if (imgEnc?.['@_url']) return upgradeImageResolution(imgEnc['@_url']);
  } else if (enclosure?.['@_url'] && (!enclosure['@_type'] || enclosure['@_type'].startsWith('image/'))) {
    return upgradeImageResolution(enclosure['@_url']);
  }

  const rawDesc = String(item['content:encoded'] ?? item['description'] ?? '');
  const imgMatch = rawDesc.match(/<img[^>]+src=["']([^"']+)["']/i);
  if (imgMatch?.[1]) {
    return upgradeImageResolution(imgMatch[1]);
  }
  return null;
}

async function fetchRssFeed(feed: FeedSource): Promise<Article[]> {
  try {
    const response = await fetch(feed.url, {
      headers: {
        'User-Agent': 'NewsReaderCollegeApp/1.0 (+https://localhost)',
        Accept: 'application/rss+xml, application/xml, text/xml',
      },
      signal: AbortSignal.timeout(7000),
    });
    if (!response.ok) return [];

    const xml = await response.text();
    const parsed = xmlParser.parse(xml) as {
      rss?: { channel?: { item?: unknown } };
    };
    const rawItems = parsed?.rss?.channel?.item;
    const items = Array.isArray(rawItems) ? rawItems : rawItems ? [rawItems] : [];

    const articles: Article[] = [];
    for (const rawItem of items.slice(0, 18)) {
      const item = rawItem as Record<string, unknown>;
      const title = cleanText(item.title);
      const rawLink = typeof item.link === 'string' ? item.link.trim() : '';
      if (!title || !rawLink || !/^https?:\/\//i.test(rawLink)) continue;

      const description = cleanText(item.description);
      const content = cleanText(item['content:encoded']) ?? description;
      const author = cleanText(item['dc:creator'] ?? item.author);
      const pubRaw = typeof item.pubDate === 'string' ? item.pubDate : '';
      const parsedDate = pubRaw ? new Date(pubRaw) : new Date();
      const publishedAt = Number.isNaN(parsedDate.getTime())
        ? new Date().toISOString()
        : parsedDate.toISOString();

      articles.push({
        id: createArticleId(rawLink),
        title,
        description,
        content,
        url: rawLink,
        imageUrl: extractImageFromItem(item),
        source: feed.source,
        author,
        category: feed.category,
        publishedAt,
      });
    }
    return articles;
  } catch {
    return [];
  }
}

async function fetchSpaceflightNews(query: string): Promise<Article[]> {
  try {
    const endpoint = new URL('https://api.spaceflightnewsapi.net/v4/articles/');
    endpoint.searchParams.set('limit', '12');
    if (query) endpoint.searchParams.set('search', query);

    const response = await fetch(endpoint, { signal: AbortSignal.timeout(6000) });
    if (!response.ok) return [];
    const data = (await response.json()) as {
      results?: Array<{
        title: string;
        url: string;
        image_url?: string | null;
        news_site?: string;
        summary?: string;
        published_at?: string;
        authors?: Array<{ name?: string }>;
      }>;
    };

    return (data.results ?? [])
      .filter((r) => r.title && r.url)
      .map((r) => ({
        id: createArticleId(r.url),
        title: r.title,
        description: r.summary?.trim() || null,
        content: r.summary?.trim() || null,
        url: r.url,
        imageUrl: upgradeImageResolution(r.image_url ?? null),
        source: r.news_site || 'Spaceflight News',
        author: r.authors?.[0]?.name || null,
        category: 'science' as const,
        publishedAt: r.published_at || new Date().toISOString(),
      }));
  } catch {
    return [];
  }
}

async function fetchHackerNewsSearch(query: string): Promise<Article[]> {
  if (!query) return [];
  try {
    const endpoint = new URL('https://hn.algolia.com/api/v1/search');
    endpoint.searchParams.set('query', query);
    endpoint.searchParams.set('tags', 'story');
    endpoint.searchParams.set('hitsPerPage', '10');

    const response = await fetch(endpoint, { signal: AbortSignal.timeout(6000) });
    if (!response.ok) return [];
    const data = (await response.json()) as {
      hits?: Array<{
        objectID: string;
        title?: string;
        url?: string;
        author?: string;
        created_at?: string;
        story_text?: string | null;
      }>;
    };

    return (data.hits ?? [])
      .filter((hit) => hit.title && hit.url && /^https?:\/\//i.test(hit.url))
      .map((hit) => ({
        id: createArticleId(hit.url as string),
        title: hit.title as string,
        description:
          cleanText(hit.story_text) ??
          `Community-curated technology and industry story matching "${query}".`,
        content: cleanText(hit.story_text),
        url: hit.url as string,
        imageUrl: null,
        source: 'Hacker News Wire',
        author: hit.author || null,
        category: 'technology' as const,
        publishedAt: hit.created_at || new Date().toISOString(),
      }));
  } catch {
    return [];
  }
}

interface NewsApiOrgResponse {
  status: string;
  totalResults?: number;
  message?: string;
  articles?: Array<{
    source?: { name?: string };
    author?: string | null;
    title?: string;
    description?: string | null;
    url?: string;
    urlToImage?: string | null;
    publishedAt?: string;
    content?: string | null;
  }>;
}

async function fetchFromNewsApiOrg(
  apiKey: string,
  category: CategoryId,
  query: string,
): Promise<{ articles: Article[]; error?: string }> {
  const endpoint = query
    ? new URL('https://newsapi.org/v2/everything')
    : new URL('https://newsapi.org/v2/top-headlines');

  if (query) {
    endpoint.searchParams.set('q', query);
    endpoint.searchParams.set('sortBy', 'publishedAt');
    endpoint.searchParams.set('language', 'en');
    endpoint.searchParams.set('pageSize', '24');
  } else {
    endpoint.searchParams.set('country', 'us');
    endpoint.searchParams.set('pageSize', '24');
    if (category !== 'all') {
      endpoint.searchParams.set('category', category);
    }
  }

  const response = await fetch(endpoint, {
    headers: { 'X-Api-Key': apiKey },
    signal: AbortSignal.timeout(8000),
  });
  const payload = (await response.json()) as NewsApiOrgResponse;

  if (!response.ok || payload.status !== 'ok') {
    return {
      articles: [],
      error: payload.message || `NewsAPI responded with HTTP ${response.status}`,
    };
  }

  const mappedCategory: NewsCategory = category === 'all' ? 'general' : category;
  const articles: Article[] = (payload.articles ?? [])
    .filter((item) => item.title && item.title !== '[Removed]' && item.url)
    .map((item) => ({
      id: createArticleId(item.url as string),
      title: item.title as string,
      description: item.description?.trim() || null,
      content: item.content?.replace(/\[\+\d+\s+chars\]$/i, '').trim() || item.description || null,
      url: item.url as string,
      imageUrl: upgradeImageResolution(item.urlToImage ?? null),
      source: item.source?.name || 'NewsAPI Source',
      author: item.author || null,
      category: mappedCategory,
      publishedAt: item.publishedAt || new Date().toISOString(),
    }));

  return { articles };
}

function deduplicateAndSort(articles: Article[]): Article[] {
  const seen = new Map<string, Article>();
  for (const article of articles) {
    const key = article.title.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 48);
    if (!seen.has(article.id) && !seen.has(key)) {
      seen.set(article.id, article);
      seen.set(key, article);
    }
  }
  const unique = Array.from(new Set(seen.values()));
  unique.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
  return unique;
}

export async function getNewsFeed(options: {
  category?: string;
  query?: string;
}): Promise<NewsFeedResponse> {
  const validCategories: CategoryId[] = [
    'all',
    'general',
    'technology',
    'business',
    'sports',
    'entertainment',
    'health',
    'science',
  ];
  const rawCategory = (options.category ?? 'all').toLowerCase() as CategoryId;
  const category: CategoryId = validCategories.includes(rawCategory) ? rawCategory : 'all';
  const query = (options.query ?? '').trim();

  const cacheKey = `${category}::${query.toLowerCase()}`;
  const cached = memoryCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.data;
  }

  let notice: string | undefined;
  const newsApiKey = process.env.NEWS_API_KEY?.trim();

  if (newsApiKey) {
    try {
      const apiRes = await fetchFromNewsApiOrg(newsApiKey, category, query);
      if (apiRes.articles.length > 0) {
        const result: NewsFeedResponse = {
          articles: apiRes.articles,
          totalResults: apiRes.articles.length,
          category,
          query,
          provider: 'NewsAPI.org',
        };
        cacheArticles(result.articles);
        memoryCache.set(cacheKey, { expiresAt: Date.now() + CACHE_TTL_MS, data: result });
        return result;
      }
      if (apiRes.error) {
        notice = `NewsAPI.org notice (${apiRes.error}). Showing live public news feeds instead.`;
      }
    } catch {
      notice = 'NewsAPI.org was temporarily unreachable. Showing live public news feeds.';
    }
  }

  const feedsToFetch: FeedSource[] =
    category === 'all'
      ? [
          ...RSS_FEEDS.general,
          RSS_FEEDS.technology[0],
          RSS_FEEDS.business[0],
          RSS_FEEDS.business[1],
          RSS_FEEDS.sports[0],
          RSS_FEEDS.sports[1],
          RSS_FEEDS.science[0],
          RSS_FEEDS.health[0],
          RSS_FEEDS.entertainment[0],
        ]
      : RSS_FEEDS[category];

  const feedPromises: Array<Promise<Article[]>> = feedsToFetch.map((feed) => fetchRssFeed(feed));

  if (category === 'science' || category === 'all' || query) {
    feedPromises.push(fetchSpaceflightNews(query));
  }
  if (query) {
    feedPromises.push(fetchHackerNewsSearch(query));
  }

  const batches = await Promise.all(feedPromises);
  let combined = deduplicateAndSort(batches.flat());

  if (query) {
    const tokens = query
      .toLowerCase()
      .split(/\s+/)
      .filter((t) => t.length > 1);
    combined = combined.filter((article) => {
      const haystack = [article.title, article.description ?? '', article.source, article.category]
        .join(' ')
        .toLowerCase();
      return tokens.every((token) => haystack.includes(token));
    });
  }

  const sliced = combined.slice(0, 30);
  if (sliced.length > 0) {
    cacheArticles(sliced);
  }

  const result: NewsFeedResponse = {
    articles: sliced,
    totalResults: sliced.length,
    category,
    query,
    provider: 'Live Public News Feeds (BBC, NYT, TechCrunch, The Hindu, ESPNcricinfo)',
    notice,
  };

  memoryCache.set(cacheKey, { expiresAt: Date.now() + CACHE_TTL_MS, data: result });
  return result;
}
