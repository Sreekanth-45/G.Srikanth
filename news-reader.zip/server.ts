import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import {
  addBookmark,
  createNote,
  deleteNote,
  getCachedArticleById,
  listBookmarks,
  listNotes,
  removeBookmark,
  updateNote,
} from './server/db.ts';
import { getNewsFeed } from './server/newsService.ts';
import type { Article } from './src/types/news.ts';

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT) || 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      newsApiConfigured: Boolean(process.env.NEWS_API_KEY?.trim()),
    });
  });

  app.get('/api/news', async (req, res) => {
    try {
      const category = typeof req.query.category === 'string' ? req.query.category : 'all';
      const query = typeof req.query.q === 'string' ? req.query.q : '';
      const feed = await getNewsFeed({ category, query });
      res.json(feed);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to fetch news feed.';
      res.status(502).json({ error: message });
    }
  });

  app.get('/api/articles/:id', (req, res) => {
    const article = getCachedArticleById(req.params.id);
    if (!article) {
      res.status(404).json({ error: 'Article not found in local session archive.' });
      return;
    }
    res.json({ article });
  });

  app.get('/api/bookmarks', (_req, res) => {
    const bookmarks = listBookmarks();
    res.json({ bookmarks });
  });

  app.post('/api/bookmarks', (req, res) => {
    const article = req.body?.article as Article | undefined;
    if (!article || !article.id || !article.url || !article.title) {
      res.status(400).json({ error: 'Valid article payload (id, url, title) is required.' });
      return;
    }
    const result = addBookmark(article);
    res.status(result.alreadyExists ? 200 : 201).json(result);
  });

  app.delete('/api/bookmarks/:id', (req, res) => {
    const removed = removeBookmark(req.params.id);
    if (!removed) {
      res.status(404).json({ error: 'Bookmark not found.' });
      return;
    }
    res.json({ removed: true, id: req.params.id });
  });

  app.get('/api/notes', (req, res) => {
    const articleId = typeof req.query.articleId === 'string' ? req.query.articleId : undefined;
    const notes = listNotes(articleId);
    res.json({ notes });
  });

  app.post('/api/notes', (req, res) => {
    const { articleId, articleUrl, articleTitle, noteContent } = req.body ?? {};
    if (
      typeof articleId !== 'string' ||
      !articleId.trim() ||
      typeof articleTitle !== 'string' ||
      !articleTitle.trim() ||
      typeof noteContent !== 'string' ||
      !noteContent.trim()
    ) {
      res.status(400).json({ error: 'articleId, articleTitle, and noteContent are required.' });
      return;
    }

    const note = createNote({
      articleId: articleId.trim(),
      articleUrl: typeof articleUrl === 'string' ? articleUrl.trim() : '',
      articleTitle: articleTitle.trim(),
      noteContent: noteContent.trim(),
    });
    res.status(201).json({ note });
  });

  app.put('/api/notes/:id', (req, res) => {
    const noteId = Number(req.params.id);
    const noteContent = req.body?.noteContent;
    if (!Number.isInteger(noteId) || typeof noteContent !== 'string' || !noteContent.trim()) {
      res.status(400).json({ error: 'Valid note id and non-empty noteContent are required.' });
      return;
    }
    const updated = updateNote(noteId, noteContent);
    if (!updated) {
      res.status(404).json({ error: 'Note not found.' });
      return;
    }
    res.json({ note: updated });
  });

  app.delete('/api/notes/:id', (req, res) => {
    const noteId = Number(req.params.id);
    if (!Number.isInteger(noteId)) {
      res.status(400).json({ error: 'Valid note id is required.' });
      return;
    }
    const deleted = deleteNote(noteId);
    if (!deleted) {
      res.status(404).json({ error: 'Note not found.' });
      return;
    }
    res.json({ deleted: true, id: noteId });
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distPath, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Production build not found. Run npm run build first.');
      }
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`News Reader server listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start News Reader server:', err);
  process.exit(1);
});
